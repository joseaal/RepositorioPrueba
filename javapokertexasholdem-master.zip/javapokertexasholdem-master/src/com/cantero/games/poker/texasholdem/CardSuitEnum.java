package com.cantero.games.poker.texasholdem;

public enum CardSuitEnum {
	CLUBS,
	DIAMONDS,
	HEARTS,
	SPADES
}