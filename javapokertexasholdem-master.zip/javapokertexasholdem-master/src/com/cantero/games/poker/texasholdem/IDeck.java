package com.cantero.games.poker.texasholdem;

public interface IDeck {
	public Card pop();
}
